package com.pgfinder.servicerazorpay.controller;

import com.pgfinder.servicerazorpay.service.PaymentService;
import com.razorpay.RazorpayException;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    private PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping("/create-order")
    public String createOrder(@RequestParam int amount) throws RazorpayException {
        return paymentService.createOrder(amount);
    }
}
