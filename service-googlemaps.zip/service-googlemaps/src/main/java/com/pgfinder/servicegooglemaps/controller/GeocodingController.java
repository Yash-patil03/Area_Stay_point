package com.pgfinder.servicegooglemaps.controller;

import com.google.maps.model.GeocodingResult;
import com.pgfinder.servicegooglemaps.service.GeocodingService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/maps")
public class GeocodingController {

    private GeocodingService geocodingService;

    public GeocodingController(GeocodingService geocodingService) {
        this.geocodingService = geocodingService;
    }

    @GetMapping("/geocode")
    public GeocodingResult[] geocode(@RequestParam String address) throws Exception {
        return geocodingService.getCoordinates(address);
    }
}
